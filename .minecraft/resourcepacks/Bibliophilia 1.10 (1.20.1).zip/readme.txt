MOD COMPATS CREDITS

- Aileron by Egshels/Team Lodestar
- Alex's Caves by AlexThe668
- Alex's Caves: Stuff & Torpedoes by Furti_Two
- Alex's Mobs by AlexThe668
- Allurement by Team Abnormals
- Amethyst Imbuement by fzzyhmstrs
- Apotheosis by Shadows_of_Fire
- Ars Elemental by Alexth99
- Ars Nouveau by baileyholl2
- Backpacked by MrCrayfish
- Better Default Biomes by Xratedjunior
- Better End by Quiqueck
- Better Nether by Quiqueck
- Bewitchment by MoriyaShiine
- Block Swapper by tinytransfem
- Charm and Charm Reforged by Svenhjol
- Consecration by TheIllusiveC4
- Copper Overhaul by ElocinDev
- Create by Simibubi
- Create: Estrogen by Mayaqq
- Create Stuff & Additions by Furti_Two
- Dash by ModdingLegacy
- Deeper and Darker by KyaniteMods
- Domestication Innovation by AlexThe668
- Dragon Enchants by FavouriteDragon
- Enchantery by Ordana
- Enlightend by lixir
- Ensorcellation by TeamCoFH
- Farmer's Delight by Vectorwing
- Galosphere by orcinus73
- Incantationem by Luligabi12/CafeteriaGuild
- I Wanna Skate by AlexThe668
- Jellyfishing by BlueDuckYT
- Leap by ModdingLegacy
- Majrusz's Enchantments/Wonderful Enchantments by Majrusz
- Marium's Soulslike Weaponry
- MrCrayfish's Gun Mod by MrCrayfish
- Origins by Apace100
- Piglin Proliferation by almightytallestred
- Shulker Enchantments by Ephys
- Soul fire'd by CrystalSpider
- Spoorn Dual Wield by spoorn
- Step by ModdingLegacy
- Supplementaries by MehVahdJukaar
- The Twilight Forest by Benimatic
- Unique Enchantments by Speiger
- Unique Enchantments Apex by Speiger
- Unique Enchantments Battle by Speiger
- Unique Enchantments Util by Speiger
- Vein Mining by TheIllusiveC4

PLEASE SUPPORT THE ORIGINAL MODS AND THEIR AUTHORS!

* OptiFine, Forge CIT, CIT Resewn, or another mod that supports the MCPatcher format must be installed for this pack to work correctly

PERMISSIONS AND CREDITS

Terms of Use
- DO NOT use any textures featured in this pack in a published or otherwise distributed project
- DO NOT redistribute this pack or post on ANY external website!!
 * only legit downloads are on Curseforge, Modrinth, and Planet Minecraft posted by PareidoliaG
- DO NOT change or modify this pack and repost without permission
- You CAN use this texture pack in a modpack
- You CAN use these textures in a PERSONAL USE ONLY pack

Texture Credits
- Credits for all textures go to PareidoliaG
- Textures are based on Minecraft book texture by Jappa
- Some textures use palettes/design ideas from the listed mods and vanilla