MOD COMPATS CREDITS

- Aileron by Egshels/Team Lodestar
- Alex's Caves by AlexThe668
- Alex's Caves: Stuff & Torpedoes by Furti_Two
- Alex's Mobs by AlexThe668
- Alex's Mobs Interaction by CrimsonCrips
- Allurement by Team Abnormals
- Amethyst Imbuement by fzzyhmstrs
- Apotheosis by Shadows_of_Fire
- Ars Elemental by Alexth99
- Ars Nouveau by baileyholl2
- Backpacked by MrCrayfish
- Better Default Biomes by Xratedjunior
- Better End by Quiqueck
- Better Nether by Quiqueck
- Bewitchment by MoriyaShiine
- Biome Makeover by Lemonszz
- Block Swapper by tinytransfem
- Combat Roll by daedelus_dev
- Consecration by TheIllusiveC4
- Create by Simibubi
- Create: Estrogen by Mayaqq
- Create: Garnished by DakotaPrideModding
- Create Stuff & Additions by Furti_Two
- Dash by ModdingLegacy
- Deeper and Darker by KyaniteMods
- Domestication Innovation by AlexThe668
- Dungeons and Taverns by Nova_Wostra
- Enchantery by Ordana
- Endless Biomes by MadoctheHadoc
- Enigmatic Legacy by Aizistral
- Enlightend by lixir
- Ensorcellation by TeamCoFH
- Farmer's Delight by Vectorwing
- Forbidden and Arcanus by cesar_zorak
- Galosphere by orcinus73
- Go Fish by Draylar1
- Hybrid Aquatic by HybridLabs
- Incantationem by Luligabi12/CafeteriaGuild
- Inventorio by Lizard_OfOz
- I Wanna Skate by AlexThe668
- Jaden's Nether Expansion by ThatJadenXgamer
- Jellyfishing by BlueDuckYT
- Leap by ModdingLegacy
- Let's Forge Bronze And Iron by szczypikrul
- Majrusz's Enchantments/Wonderful Enchantments by Majrusz
- Marium's Soulslike Weaponry
- Mo' Enchantments by geosava
- My Nether's Delight by soytutta
- Origins by Apace100
- Passable Foliage by Snownee
- Piglin Proliferation by almightytallestred
- Soul fire'd by CrystalSpider
- Spoorn Dual Wield by spoorn
- Step by ModdingLegacy
- Supplementaries by MehVahdJukaar
- The Bumblezone by telepathicgrunt
- The Twilight Forest by Benimatic
- Vein Mining by TheIllusiveC4
- Wizards (RPG Series) by daedelus_dev 

PLEASE SUPPORT THE ORIGINAL MODS AND THEIR AUTHORS!

* OptiFine, Forge CIT, CIT Resewn, or another mod that supports the MCPatcher format must be installed for this pack to work correctly

PERMISSIONS AND CREDITS

Terms of Use
- DO NOT use any textures featured in this pack in a published or otherwise distributed project
- DO NOT redistribute this pack or post on ANY external website!!
 * only legit downloads are on Curseforge, Modrinth, and Planet Minecraft posted by PareidoliaG
- DO NOT change or modify this pack and repost without permission
- You CAN use this texture pack in a modpack
- You CAN use these textures in a PERSONAL USE ONLY pack

Texture Credits
- Credits for all textures go to PareidoliaG
- Textures are based on Minecraft book texture by Jappa
- Some textures use palettes/design ideas from the listed mods and vanilla